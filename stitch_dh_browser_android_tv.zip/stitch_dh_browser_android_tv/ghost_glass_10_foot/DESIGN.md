---
name: Ghost Glass 10-Foot
colors:
  surface: '#16111c'
  surface-dim: '#16111c'
  surface-bright: '#3c3743'
  surface-container-lowest: '#100c16'
  surface-container-low: '#1e1a24'
  surface-container: '#221e28'
  surface-container-high: '#2d2833'
  surface-container-highest: '#38333e'
  on-surface: '#e9dfee'
  on-surface-variant: '#d0c2d5'
  inverse-surface: '#e9dfee'
  inverse-on-surface: '#332e3a'
  outline: '#998d9e'
  outline-variant: '#4d4353'
  surface-tint: '#e0b6ff'
  primary: '#e0b6ff'
  on-primary: '#4c007d'
  primary-container: '#9d4edd'
  on-primary-container: '#fffdff'
  inverse-primary: '#8433c4'
  secondary: '#deb7ff'
  on-secondary: '#4a007f'
  secondary-container: '#6b13af'
  on-secondary-container: '#d4a5ff'
  tertiary: '#e5b5ff'
  on-tertiary: '#481965'
  tertiary-container: '#9261b0'
  on-tertiary-container: '#fffdff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#f2daff'
  primary-fixed-dim: '#e0b6ff'
  on-primary-fixed: '#2e004e'
  on-primary-fixed-variant: '#6a0baa'
  secondary-fixed: '#f1dbff'
  secondary-fixed-dim: '#deb7ff'
  on-secondary-fixed: '#2d0050'
  on-secondary-fixed-variant: '#680eac'
  tertiary-fixed: '#f4d9ff'
  tertiary-fixed-dim: '#e5b5ff'
  on-tertiary-fixed: '#30004b'
  on-tertiary-fixed-variant: '#60327d'
  background: '#16111c'
  on-background: '#e9dfee'
  surface-variant: '#38333e'
typography:
  display:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 68px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: 0em
  body-lg:
    fontFamily: Outfit
    fontSize: 22px
    fontWeight: '400'
    lineHeight: 32px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Outfit
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Outfit
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0.02em
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 22px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 2rem
  margin: 3.5rem
  space-xs: 0.5rem
  space-sm: 1rem
  space-md: 1.5rem
  space-lg: 2.25rem
  space-xl: 3.5rem
---

## Brand & Style

This design system defines an ambient, high-fidelity browsing experience engineered specifically for Android TV and large-format 10-foot displays. It combines the optical depth and translucency of Apple-inspired glassmorphism with an ominous, magnetic Gengar-inspired deep purple twilight aesthetic.

The visual style merges ultra-deep abyss blacks with layered frosted acrylics, electric purple neon luminosity, and sharp specular surface highlights. The emotional intent is cinematic, frictionless, and premium—eliminating the clunky, desktop-derived ergonomics typical of television web browsers. Interactions prioritize calm clarity across living room viewing distances, delivering instant spatial awareness through high-contrast glowing focus states tailored for D-pad, remote clicker, and spatial cursor control.

## Colors

The palette is anchored in abyssal shadows and charged with chromatic purple luminescence:

- **Primary (`#9D4EDD`)**: The primary kinetic indicator. Used for active glowing focus rings, highlighted actions, live shield animations, and active state glass glows.
- **Secondary (`#7B2CBF`)**: Deep rich purple backing. Used for focused surface fills, prominent glass rim lighting, and primary button gradients.
- **Tertiary (`#E0AAFF`)**: Lavender-tinted spectral accent. Reserved for high-visibility focus borders, active D-pad cursor beads, selected tabs, and high-contrast typographic callouts across large panels.
- **Neutral (`#0F0B15`)**: Deep violet-black void. Base background canvas across the 10-foot screen that prevents backlight bleed on OLED and LED displays.

### Semantic Tones & Translucency
- **Surface Abyss**: `#07040A` (solid background canvas).
- **Glass Base (Unfocused)**: `rgba(26, 16, 38, 0.45)` with `backdrop-filter: blur(28px)`.
- **Glass Elevated (Unfocused Card/Bar)**: `rgba(36, 0, 70, 0.55)` with `backdrop-filter: blur(36px)`.
- **Glass Focused Surface**: `rgba(90, 24, 154, 0.40)` with `rgba(157, 78, 221, 0.25)` specular wash.
- **Border Rim (Default)**: `rgba(224, 170, 255, 0.12)`.
- **Border Rim (Focused)**: `#E0AAFF` accompanied by a `0 0 24px rgba(157, 78, 221, 0.65)` neon aura.
- **Shield Active (Protected)**: `#00F5D4` (emerald neon) over translucent purple backing.
- **Shield Warning / Paused**: `#FF9E00` (amber neon).

## Typography

Typography is specifically scaled for the 10-foot television viewing cone (viewers sitting 2.5–4 meters from screens ranging 43–85+ inches).

- **Space Grotesk** governs structural titles, floating navigation tabs, URLs, and status trackers. Its geometric, slightly technical chassis reinforces precision and navigational crispness.
- **Outfit** handles bookmarks, reading mode body text, sub-labels, and metadata. Its rounded geometric forms maintain optical openness and eliminate legibility fatigue across heavy diffusion blurs.

Minimum body size is strictly locked at 15px (1080p reference baseline; scales to 30px on 4K buffers) to guarantee remote legibility without squinting. Font weights below 400 are prohibited to prevent thin glyphs from dissolving over vibrant background media or blurred backdrops.

## Layout & Spacing

The layout is built for standard 16:9 television screens running at 1080p and 4K UHD resolutions.

- **Over-scan Safe Margin**: TV panels require an outer boundary buffer. A persistent `margin` of `3.5rem` (56px in 1080p / 112px in 4K) wraps all interactive UI bounds. Essential controls and text never enter this zone.
- **Navigation Spatial Grid**: The home interface uses a dynamic 6-column grid for primary bookmark tiles and quick links, collapsing to a single-row virtual horizontal carousel when navigating via D-pad horizontal snaps.
- **Focus Padding Expansion**: Every interactive tile includes a mandatory clear separation via `gutter: 2rem` to allow D-pad focus states to scale outward (+6% to +10%) without clipping or occluding adjacent tiles.

## Shapes

The interface embraces a unified soft-curvilinear geometry (`roundedness: 2`).

- **Bookmark Tiles & Content Cards**: Bound by `rounded-lg` (1rem / 16px at 1080p). This geometry preserves the structural card look while echoing modern display corners.
- **Navigation Capsule & Search Pill**: The top bar, omnibox input, and floating status bubbles use continuous capsule/pill contours (`rounded-xl` or full circular radiuses on button ends).
- **Focus Rings**: Focus borders match the exact curvature of the underlying element, maintaining a constant 3px offset or snug 2px outer track without corner deformation.

## Components

### Floating Navigation Bar
A self-contained glass bar pinned to the top screen tier within safe margins. Houses:
- **Shield Indicator**: Pill chip showing real-time tracker counts. Features a pulsating emerald dot when active (`#00F5D4`) on deep purple glass.
- **Omnibox / URL Field**: Semi-translucent inset field showing the domain in high-contrast white with HTTPS lock indicator.
- **Voice Search Trigger**: Dedicated micro-capsule with an electric purple microphone icon, glowing brighter upon focus.
- **History & Tabs Switcher**: Compact icon toggle with counter badges rendered in Space Grotesk.

### Bookmark Tiles
- Dimensions: 16:10 aspect ratio frosted glass slabs.
- Unfocused: Dim translucent purple glass, subdued favicon, high-legibility site title in `label-md`.
- Focused: Scales up +6%, border flares to bright `#E0AAFF`, background shifts from dark violet to illuminated `#5A189A`, and a soft purple glow illuminates the canvas beneath.

### Remote / D-Pad Focus Rings
- All focus rings are persistent and non-transient. The user must never lose track of where the remote cursor sits.
- Composed of an inner high-contrast stroke (`#E0AAFF`) and an outer neon aura blur (`0 0 28px #9D4EDD`).
- Spatial transitions between elements use snappy spring curves (200ms cubic-bezier(0.2, 0.9, 0.3, 1)) to provide instant tactile feedback from remote clicks.

### Shield & Ad-Blocker Drawer
- Triggered by focusing the shield indicator. Drops down as a glass card panel.
- Contains high-contrast toggle switches: Trackers Blocked, Popups Killed, Fingerprint Protection.
- Toggles utilize pill-shaped sliders with bright neon purple active states and muted dark amethyst inactive states.

### Virtual Cursor (Freeform Pointer Mode)
- For web pages requiring desktop-style pointer input, the browser provides a soft-glowing circular reticle.
- Cursor geometry: Dual-ring translucent purple sphere with a bright white center tracking point and a subtle trailing blur effect.

### Buttons & Chips
- **Action Buttons**: Glass capsules with `padding: 0.75rem 1.5rem`. Default state features ghost borders; focused state illuminates with high-contrast violet gradients (`#7B2CBF` to `#9D4EDD`).
- **Filter Chips (History / Categories)**: Low-profile translucent chips that fill to solid `#5A189A` with crisp `#E0AAFF` typography when selected.